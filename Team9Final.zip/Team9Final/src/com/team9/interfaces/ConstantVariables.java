package com.team9.interfaces;

public interface ConstantVariables {

	public static final double MAX_LIMIT = 1000;	//Maximum buying limit
	
}
