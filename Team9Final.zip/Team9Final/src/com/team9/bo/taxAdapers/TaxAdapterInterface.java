package com.team9.bo.taxAdapers;

public interface TaxAdapterInterface {
	// Tax adapter interface
	double getTax(double itemPrice);

}